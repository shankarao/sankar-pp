import { Component, OnInit } from '@angular/core';
import { Account } from 'src/app/Entity/Account';
import { Transactions } from 'src/app/Entity/Transactions';
import { Router } from '@angular/router';
import { BankService } from 'src/app/Service/bank.service';

@Component({
  selector: 'withdrawal',
  templateUrl: './withdrawal.component.html',
  styleUrls: ['./withdrawal.component.css']
})
export class WithdrawalComponent implements OnInit {

  isLogin:boolean=true;
  accounts:Account[]=[];
  createdTransaction:Transactions;
  router:Router;
  
  service:BankService;
  constructor(service:BankService,router:Router) { 
    this.service=service;
    this.isLogin=this.service.isLogin;
    this.router=router;
  }
  withdraw(data:any){
    let accBal=data.accBal;
    var transType:string;
    transType="Withdraw";
    var bal=this.service.withdraw(data.accNum,accBal);
    bal.subscribe
    (
    (data) => {
      alert("Updated Balance : "+data)
        this.service
        // this.service.convert(data);
    }
    )
    this.router.navigate(['home']);
  }

  ngOnInit() {
    this.accounts=this.service.getAccounts();
  }
}
