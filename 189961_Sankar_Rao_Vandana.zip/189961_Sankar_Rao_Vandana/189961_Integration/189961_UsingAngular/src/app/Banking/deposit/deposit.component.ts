import { Component, OnInit } from '@angular/core';
import { Account } from 'src/app/Entity/Account';
import { Transactions } from 'src/app/Entity/Transactions';
import { Router } from '@angular/router';
import { BankService } from 'src/app/Service/bank.service';

@Component({
  selector: 'deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {

  isLogin:boolean=true;
  accounts:Account[]=[];
  createdTransaction:Transactions;
  router:Router;

  service:BankService;
  constructor(service:BankService,router:Router) { 
    this.service=service;
    this.isLogin=this.service.isLogin;
    this.router=router;
  }

  deposit(data:any){
   
    let accBal=data.accBal;
    var transType:string;
    transType="Deposit";
    var bal=this.service.deposit(data.accNum,accBal);
    bal.subscribe
    (
    (data) => {
      alert("Updated Balance : "+data)
        this.service
        // this.service.convert(data);
    }
    )
    this.router.navigate(['home']);
  }


  ngOnInit() {
    this.accounts=this.service.getAccounts();
  }

}
