import { Component, OnInit } from '@angular/core';
import { BankService } from 'src/app/Service/bank.service';
import { Router } from '@angular/router';
import { Account } from 'src/app/Entity/Account';

@Component({
  selector: 'banking',
  templateUrl: './banking.component.html',
  styleUrls: ['./banking.component.css']
})
export class BankingComponent implements OnInit {

  service:BankService;
  router:Router;

  constructor(service:BankService,router:Router) { 
    this.service=service;
    this.router=router;
  }

  accounts:Account[]=[];
  isLogin:boolean=true;

  login(data:any){
    if(this.service.login(data)){
      this.isLogin=this.service.isLogin;
      this.router.navigate(['home']);
    }else{
      alert("Invalid Credentials")
    }
  }

  ngOnInit() {
    this.service.fetchAccounts();
    this.accounts=this.service.getAccounts();
  }
}
