package org.cg.bank.service;

import java.util.List;

import org.cg.bank.bean.Bank;
import org.cg.bank.exceptions.AccountAlreadyExistsException;
import org.cg.bank.exceptions.AccountNotFoundException;
import org.cg.bank.exceptions.InsufficientBalanceException;


public interface BankProjectServiceI {

	public boolean createAccount(String name, String add, long accNo, String phone, int pin, int bal)
			throws AccountAlreadyExistsException;

	public int showBalance(long accNo) throws AccountNotFoundException;

	public int deposit(long accNo, int deposit_amount) throws AccountNotFoundException;

	public int withdraw(long accNo, int withdraw_amount) throws AccountNotFoundException, InsufficientBalanceException;

	public boolean transferfund(long accNo, long accNo1, int transfer_amount)
			throws AccountNotFoundException, InsufficientBalanceException;

	public boolean validateBalance(long accNo, int amount) throws InsufficientBalanceException;

	public String setTrans(long accNo) throws AccountNotFoundException;
	
	public List<Bank> getAllAccounts();

}
