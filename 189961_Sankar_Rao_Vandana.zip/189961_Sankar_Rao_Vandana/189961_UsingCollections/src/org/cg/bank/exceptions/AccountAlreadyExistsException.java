package org.cg.bank.exceptions;

@SuppressWarnings("serial")
public class AccountAlreadyExistsException extends Exception {

	public AccountAlreadyExistsException() {

	}

	@Override
	public String toString() {
		return "Account is already Existed please try again later";
	}

}
