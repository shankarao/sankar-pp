package org.cg.bank.ui;

import java.util.List;
import java.util.Random;
import java.util.Scanner;

import org.cg.bank.bean.Bank;
import org.cg.bank.exceptions.AccountAlreadyExistsException;
import org.cg.bank.exceptions.AccountNotFoundException;
import org.cg.bank.exceptions.InsufficientBalanceException;
import org.cg.bank.service.BankProjectServiceI;
import org.cg.bank.service.BankProjectServiceImpl;


public class Main {
	// for displaying the Menu
	public static int menu() {

		System.out.println(" ******************************* Welcome to SBI Bank *********************************");
		System.out.println("choose 1 to Create your Account");
		System.out.println("choose 2 to Show Balance");
		System.out.println("choose 3 to Deposit Amount");
		System.out.println("choose 4 to Withdraw Money");
		System.out.println("choose 5 to Transfer Your Funds");
		System.out.println("choose 6 to Print Transcations");
		System.out.println("choose 7 to Show Accounts");
		System.out.println("choose 8 to Exit");
		System.out.println("Enter your Choice");
		int choice = scan.nextInt();

		String str = Integer.toString(choice);
		String pattern = ("[0-8]{1}");
		while (!str.matches(pattern)) {
			System.out.println("You have entered inalid choice");
			System.out.println("Enter your Choice Again");
			choice = scan.nextInt();
		}
		return choice;
	}
	static Scanner scan = new Scanner(System.in);

	public static void main(String[] args) throws AccountNotFoundException {

		// variables taken

		long accNum, accNum1;
		int amount_withdraw, amount_deposit = 0, amount_transfer = 0;
		int pin;
		@SuppressWarnings("unused")
		int amount = 0;
		int balance = 0;
		boolean vin = false;

		BankProjectServiceI service = new BankProjectServiceImpl();

		String cons = "yes";

		while (cons.equalsIgnoreCase("yes")) {

			switch (menu()) {

			// to create account

			case 1:

				System.out.println("Enter your Name");
				String name = scan.nextLine();
				name += scan.nextLine();

				

				System.out.println("Enter your address ");
				String address = scan.next();
				address += scan.nextLine();

				

				System.out.println("Enter your phone number");
				String phone = scan.next();

				while (phone.length() < 10 || phone.length() > 10) {

					System.out.println("Phone number should be of 10 digits");
					System.out.println("Enter your phone number");
					phone = scan.next();
				}

				Random r = new Random();
				accNum = r.nextInt();

				System.out.println("Enter your Pin");
				pin = scan.nextInt();

				while (String.valueOf(pin).length() < 6 || String.valueOf(pin).length() > 6) {

					System.out.println("Pin number should be 6 digits");
					System.out.println("Enter your Pin");
					pin = scan.nextInt();
				}

				System.out.println("Enter your Balance");
				int bal = scan.nextInt();

				while (bal < 100) {
					System.out.println("Minimum Balance should be 100");
					System.out.println("Enter your Balance");
					bal = scan.nextInt();

				}
				try {
					vin = service.createAccount(name, address, accNum, phone, pin, bal);
				} catch (AccountAlreadyExistsException e) {

					System.out.println(e);
					break;
				}

				if (vin == true) {
					System.out.println(" Successfully Account Created.....)");
					System.out.println("Account Number : " + accNum);

				} else {

					System.out.println("Account creation failed");
				}

				break;

			// to show balance
			case 2:

				System.out.println("Enter your account number to know your balance");
				accNum = scan.nextLong();

				try {
					balance = service.showBalance(accNum);
				} catch (AccountNotFoundException e) {
					System.out.println(e);
					break;
				}

				System.out.println("Balance :" + balance);

				break;

			// to deposit

			case 3:

				System.out.println("Enter your account number");
				accNum = scan.nextLong();

				System.out.println("Enter amount to be deposited");
				amount_deposit = scan.nextInt();

				try {
					amount = service.deposit(accNum, amount_deposit);

					balance = service.showBalance(accNum);
				}

				catch (AccountNotFoundException e) {

					System.out.println(e);
					break;
				}

				System.out.println("Amount Deposited : " + amount_deposit);
				System.out.println("Updated Balance : " + balance);

				break;

			// to withdraw

			case 4:

				System.out.println("Enter your account no");
				accNum = scan.nextLong();

				System.out.println("Enter amount to withdraw");
				amount_withdraw = scan.nextInt();

				try {
					amount = service.withdraw(accNum, amount_withdraw);
					vin = service.validateBalance(accNum, amount_withdraw);
					balance = service.showBalance(accNum);

				} catch (AccountNotFoundException e) {

					System.out.println(e);
					break;

				} catch (InsufficientBalanceException e) {

					System.out.println(e);
					break;
				}

				System.out.println("Amount Withdrawn : " + amount_withdraw);
				System.out.println("Updated Balance : " + balance);

				break;

			// to transfer fund

			case 5:

				int senderbal = 0;
				int recieverbal = 0;

				System.out.println("Enter account tour no");
				accNum = scan.nextLong();

				System.out.println("Enter account to reciever account number");
				accNum1 = scan.nextLong();

				System.out.println("Enter amount to transfer");
				amount_transfer = scan.nextInt();

				try {
					vin = service.validateBalance(accNum, amount_transfer);
					vin = service.transferfund(accNum, accNum1, amount_transfer);

					senderbal = service.showBalance(accNum);
					recieverbal = service.showBalance(accNum1);

				} catch (AccountNotFoundException e) {

					System.out.println(e);
					break;
				} catch (InsufficientBalanceException e) {
					System.out.println(e);
					break;
				}

				System.out.println("  Amount Successfully Transferred");
				System.out.println("Balance Updated " + accNum + " : " + senderbal);
				System.out.println("Balance Updated " + accNum1 + " : " + recieverbal);

				break;

			// for showing transactions
			case 6:

				String s = null;
				System.out.println("Enter your account number");
				accNum = scan.nextLong();
				
				try {
					s = service.setTrans(accNum);
					System.out.println(s);
				} catch (AccountNotFoundException e) {
					System.out.println(e);
					break;
				}
			case 7:
				List<Bank> accounts = service.getAllAccounts();
				System.out.println(accounts);
				// for exiting
				break;
			case 8:
				cons = "No";
				System.out.println("Thank you for using our bank .....");
				System.exit(0);

				break;
			default:
				System.out.println("Please Enter choice between 1 - 7 ");
				menu();

			}
		}
	}



}
