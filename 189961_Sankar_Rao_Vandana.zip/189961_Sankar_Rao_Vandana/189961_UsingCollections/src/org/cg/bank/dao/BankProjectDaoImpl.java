package org.cg.bank.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import org.cg.bank.bean.Bank;

public class BankProjectDaoImpl implements BankProjectDao {

	HashMap<Long, Bank> h1;

	public BankProjectDaoImpl() {

		h1 = new HashMap<Long, Bank>();
	}

	// bean class object

	Bank b = new Bank();

	// to check account already exists or not

	public Bank checkAccount(long accNo) {

		if (h1.containsKey(accNo)) {

			b = (Bank) h1.get(accNo);
			return b;

		} else

			return null;
	}

	// to put the data into the map

	public void setData(long accNo, Bank bean) {

		h1.put(accNo, bean);
	}

	@Override
	public List<Bank> getAllBankAccounts() {
		Set<Long> keys = this.h1.keySet();
		List<Bank> accounts= new ArrayList<>();
		for (Long key : keys) {
			accounts.add(this.h1.get(key));
		}
		return accounts;
	}

}
