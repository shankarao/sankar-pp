package com.bank.main;
import java.util.Scanner;

import com.bank.entity.BankDetails;
import com.bank.entity.TransactionDetails;
import com.bank.service.BankService;
import com.cg.exception.InvalidException;
public class MainUi {
	public static void Menu()
	{
		System.out.println("*************WELCOME TO SBI BANK***************");
		System.out.println("----------------------------------------------------------------");
		System.out.println("choose 1 to CreateAccount");
		System.out.println("choose 2 to Show Balance");
		System.out.println("choose 3 to Deposit Amount");
		System.out.println("choose 4 to Withdraw Money");
		System.out.println("choose 5 to Transfer Your Funds");
		System.out.println("choose 6 to Print Transcations");
		System.out.println("choose 7 to Exit");
		System.out.println("*-**-*-*-*-*-*-*-*-*-*-*-*-*-*--*-*-*--*--*-*-*-*-*-*-*-*-*-*-\n");
	}
	public static void main(String[] args) throws InvalidException {
		do{
			Menu();
		
		 Scanner sc=new Scanner(System.in);
		 BankService service=new BankService();
		 BankDetails bank=new BankDetails();
		 TransactionDetails trans=new TransactionDetails();
		 TransactionDetails trans1=new TransactionDetails();
	 int opt=sc.nextInt();
		 
	 switch(opt)
	 {
	 case 1:
		 System.out.println("For Creation account");
		 System.out.println("Enter Account Name");
		 String name=sc.next();
		
		 System.out.println("Enter Mobile Number");
		 String mobileno=sc.next();
		 if(mobileno.length()!=10)
		 {
			 throw new InvalidException("Enter valid Mobile Number");
		 }
		 
		 bank.setAccId();
		 bank.setAccountantName(name);
		 bank.setMobileno(mobileno);
		 bank.setAccBalance(1000);
		 
		//Service class calling
		 service.CreateAccount(bank);	
		 
		 System.out.println(" Successfully Inserted ......");
		 int id=bank.getAccId();
		 service.getAccountById(id);
		 System.out.println("Your ACCOUNT ID is :"+bank.getAccId());
		 
		 System.out.println("-------------------------------------------------------------");
	  break;
	 case 2:
		 System.out.println("Enter your ID for checking bank details");
		 int accid=sc.nextInt();
		 if(accid==0)
		 {
			 throw new InvalidException("Enter valid Account Id");
		 }
		 bank=service.getAccountById(accid);
		 System.out.println("Accountant Name: "+bank.getAccountantName());
		 System.out.println(" Your present Account Balance is: "+bank.getAccBalance());
		 System.out.println("\n-------------------------------------------------------------");
		 break;
		 
	 case 3:
		 System.out.println("Deposit Process...");
		 System.out.println("Enter your Account ID");
		 int depId=sc.nextInt();
		 if(depId==0)
		 {
			 throw new InvalidException("Enter valid Account Id");
		 }
		 bank=service.getAccountById(depId);	
		 System.out.println("Accountant Name: "+bank.getAccountantName());
		 System.out.println(" Your present Account Balance is: "+bank.getAccBalance());
		 int initbal=bank.getAccBalance();
		 System.out.println("Enter the Amount you want to Deposit");
		 int depAmt=sc.nextInt();
		 int finalbal=initbal+depAmt;
		 bank.setAccBalance(finalbal);
		 service.Deposit(bank);

		 //Updating In Transaction Table
		 
		 trans.setTransactionType("Deposit");
		 trans.setAccId(depId);
		 trans.setAmount(depAmt);
		 service.addTransaction(trans);
		 bank.setT(trans);
		 
		 
		 bank=service.getAccountById(depId);
		 System.out.println("Your Account Balance after Depositing "+depAmt+" Rs is "+bank.getAccBalance());
		
		 break;
	 case 4:
		 System.out.println("Withdraw Process");
		 System.out.println("Enter your account Id");
		 int wid=sc.nextInt();
		 if(wid==0)
		 {
			 throw new InvalidException("Enter valid Account Id");
		 }
		 bank=service.getAccountById(wid);						
	
		 System.out.println(" Your Account Balance is: "+bank.getAccBalance());
		 int intbal=bank.getAccBalance();							//initial balance
		
		 System.out.println("Enter the Amount you want to Withdraw");
		 int wamt=sc.nextInt();
		 int finalBal=intbal-wamt;
		 bank.setAccBalance(finalBal);
 		 service.Withdraw(bank);
 		 
 		 
		 //Updating In Transaction Table
		 trans.setTransactionType("Withdraw");
		 trans.setAccId(wid);
		 trans.setAmount(wamt);
		 service.addTransaction(trans);
		 bank.setT(trans);
		 
		 bank=service.getAccountById(wid);
	
		 System.out.println("Your Present Account Balance after Withdrawing from your account "+wamt+" Rs is"+bank.getAccBalance());
		 System.out.println("\n-------------------------------------------------------------\n");
		 break;
	 case 5:
		 System.out.println("Fund Transfer....!!");
		 System.out.println("Enter the From Account ID");
		 int fid=sc.nextInt();	//From Account Id (Sender)
		 if(fid==0)
		 {
			 throw new InvalidException("Enter valid Account Id");
		 }
		 bank=service.getAccountById(fid);
		 int bal=bank.getAccBalance();						//Initial Balance
		 System.out.println("Enter the amount you want to transfer");
		 int fund=sc.nextInt();	//Amount to be transfered
		 System.out.println("Enter Reciever Account Id");
		 
		 int tid=sc.nextInt();
		 if(tid==0)
		 {
			 throw new InvalidException("Enter valid Account Id");
		 }
		 
		//Removing the Balance transfered from sender Account 
		 bank=service.getAccountById(fid);
		 int bal1=bal-fund;
		 bank.setAccBalance(bal1);
		 service.Deposit(bank);
		 
		 //updating the Balance recieved from Sender
		 bank=service.getAccountById(tid);
		 int tbal=bank.getAccBalance();
		 int tbalance=tbal+fund;
		 bank.setAccBalance(tbalance);
		 service.Deposit(bank);
		
		 
		 //updating In transaction Table
		 trans.setTransactionType("Transfered to "+tid);
		 trans.setAccId(fid);
		 trans.setAmount(fund);
		 service.addTransaction(trans);
		 bank.setT(trans);
		 int a= trans.getTransactionId();
		 
		/*//Updating In transaction Table
		 trans1.setTransactionId(a);
		 trans1.setTransactionType("Recieved From"+fid);
		 trans1.setAccId(tid);
		 trans1.setAmount(fund);
		 service.addTransaction(trans1);
		 bank.setT(trans1);
		 
		 */
		
		 bank=service.getAccountById(fid);
		 System.out.println("helooo...."+bank.getAccountantName());
		 System.out.println("Remaining balance in account "+bank.getAccBalance());
		 System.out.println("\n-------------------------------------------------------------\n");
		 break;
		 
	 case 6:
		System.out.println("Print Transaction");
		System.out.println("Enter the account id");
		int trid=sc.nextInt();
		//trans.setAccId(trid);
		service.PrintTransactions(trid);
		 System.out.println("\n\n-------------------------------------------------------------");
		 break;
	 case 7:
		 System.out.println("THANK YOU FOR VISITING US......................!!!!!!!");
		 System.exit(0);
	 }
	}while(true);
}
}